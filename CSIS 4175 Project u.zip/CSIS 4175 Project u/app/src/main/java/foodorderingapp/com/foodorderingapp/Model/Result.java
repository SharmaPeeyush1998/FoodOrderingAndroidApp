package foodorderingapp.com.foodorderingapp.Model;

public class Result {
    public String message_id;
}
